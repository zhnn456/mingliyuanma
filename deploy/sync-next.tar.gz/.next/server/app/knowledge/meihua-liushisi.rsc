1:"$Sreact.fragment"
2:I[11761,["5000","static/chunks/5000-6069b3cb607b49d4.js","7177","static/chunks/app/layout-ea5234c7de25d6de.js"],"Providers"]
3:I[99787,["5000","static/chunks/5000-6069b3cb607b49d4.js","7177","static/chunks/app/layout-ea5234c7de25d6de.js"],"default"]
4:I[95545,["5000","static/chunks/5000-6069b3cb607b49d4.js","7177","static/chunks/app/layout-ea5234c7de25d6de.js"],"Header"]
5:I[4707,["5000","static/chunks/5000-6069b3cb607b49d4.js","7177","static/chunks/app/layout-ea5234c7de25d6de.js"],"ErrorBoundary"]
6:I[9766,[],""]
7:I[98924,[],""]
8:I[52619,["5000","static/chunks/5000-6069b3cb607b49d4.js","8173","static/chunks/app/knowledge/%5Bid%5D/page-5b6e3a79470f8f48.js"],""]
9:I[97923,["5000","static/chunks/5000-6069b3cb607b49d4.js","7177","static/chunks/app/layout-ea5234c7de25d6de.js"],"Footer"]
b:I[24431,[],"OutletBoundary"]
d:I[15278,[],"AsyncMetadataOutlet"]
14:I[57150,[],""]
:HL["/_next/static/css/8f2129ebdce9b54e.css","style"]
0:{"P":null,"b":"x8DgCZ--psmfPWpDQIJsp","p":"","c":["","knowledge","meihua-liushisi"],"i":false,"f":[[["",{"children":["knowledge",{"children":[["id","meihua-liushisi","d"],{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/8f2129ebdce9b54e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"zh-CN","children":["$","body",null,{"className":"min-h-screen flex flex-col bg-parchment-100","children":["$","$L2",null,{"children":[["$","$L3",null,{}],["$","$L4",null,{}],["$","main",null,{"className":"flex-1","children":["$","$L5",null,{"children":["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"min-h-screen flex items-center justify-center bg-gray-50","children":["$","div",null,{"className":"text-center max-w-md px-4","children":[["$","div",null,{"className":"text-8xl mb-6","children":"🔮"}],["$","h1",null,{"className":"text-4xl font-bold text-gray-900 mb-4","children":"404"}],["$","h2",null,{"className":"text-xl text-gray-700 mb-4","children":"页面未找到"}],["$","p",null,{"className":"text-gray-500 mb-8","children":"您访问的页面不存在，可能是链接已失效或输入了错误的地址。 不妨试试去首页看看？"}],["$","div",null,{"className":"flex flex-col sm:flex-row gap-4 justify-center","children":[["$","$L8",null,{"href":"/","className":"btn-primary px-8 py-3 inline-block","children":"返回首页"}],["$","$L8",null,{"href":"/bazi","className":"btn-outline px-8 py-3 inline-block","children":"开始排盘"}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400","children":"知微阁 · 传承智慧 · 启迪人生"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}],["$","$L9",null,{}]]}]}]}]]}],{"children":["knowledge",["$","$1","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["id","meihua-liushisi","d"],["$","$1","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":["$La",null,["$","$Lb",null,{"children":["$Lc",["$","$Ld",null,{"promise":"$@e"}]]}]]}],{},null,false]},null,false]},null,false]},[["$","div","l",{"className":"min-h-screen bg-gray-50 py-8","children":["$","div",null,{"className":"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6","children":[["$","div",null,{"className":"text-center space-y-2","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-8 w-48 mx-auto"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-5 w-80 mx-auto"}]]}],["$","div",null,{"className":"card space-y-5","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-5 w-20"}],["$","div",null,{"className":"flex gap-2","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-20"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-20"}]]}],["$","div",null,{"className":"grid grid-cols-3 gap-4","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-20"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-20"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-20"}]]}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-12 w-full"}]]}],["$","div",null,{"className":"card space-y-4","children":[["$","div",null,{"className":"flex items-center justify-between","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-6 w-24"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-8 w-20 rounded-full"}]]}],["$","div",null,{"className":"space-y-3","children":[["$","div",null,{"className":"grid grid-cols-4 gap-4","children":[["$","div","1",{"className":"space-y-2","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-5 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-6 w-full"}]]}],["$","div","2",{"className":"space-y-2","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-5 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],"$Lf"]}],"$L10","$L11"]}],"$L12"]}]]}]]}]}],[],[]],false],"$L13",false]],"m":"$undefined","G":["$14",[]],"s":false,"S":true}
15:I[24431,[],"ViewportBoundary"]
17:I[24431,[],"MetadataBoundary"]
18:"$Sreact.suspense"
f:["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-6 w-full"}]
10:["$","div","3",{"className":"space-y-2","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-5 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-6 w-full"}]]}]
11:["$","div","4",{"className":"space-y-2","children":[["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-5 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-10 w-full"}],["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-6 w-full"}]]}]
12:["$","div",null,{"className":"animate-pulse bg-gray-200 rounded h-8 w-full"}]
13:["$","$1","h",{"children":[null,[["$","$L15",null,{"children":"$L16"}],null],["$","$L17",null,{"children":["$","div",null,{"hidden":true,"children":["$","$18",null,{"fallback":null,"children":"$L19"}]}]}]]}]
a:[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"Article\",\"headline\":\"六十四卦速查\",\"description\":\"六十四卦是《易经》的核心内容，由八卦两两相重而成，每卦都有独特的卦名、卦象和含义，是梅花易数断卦的基础。\",\"articleSection\":\"梅花易数\",\"keywords\":\"六十四卦,易经,卦象,速查\",\"inLanguage\":\"zh-CN\",\"author\":{\"@type\":\"Organization\",\"name\":\"知微阁\",\"url\":\"https://ming8.online\"},\"publisher\":{\"@type\":\"Organization\",\"name\":\"知微阁\",\"url\":\"https://ming8.online\"},\"mainEntityOfPage\":{\"@type\":\"WebPage\",\"@id\":\"https://ming8.online/knowledge/meihua-liushisi\"},\"datePublished\":\"2026-01-01\",\"dateModified\":\"2026-08-12\"}\n{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"首页\",\"item\":\"https://ming8.online\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"传统文化学堂\",\"item\":\"https://ming8.online/knowledge\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"梅花易数\",\"item\":\"https://ming8.online/knowledge?category=meihua\"},{\"@type\":\"ListItem\",\"position\":4,\"name\":\"六十四卦速查\",\"item\":\"https://ming8.online/knowledge/meihua-liushisi\"}]}"}}],["$","div",null,{"className":"min-h-screen bg-gradient-to-b from-parchment-50 via-paper to-white py-8","children":["$","div",null,{"className":"max-w-5xl mx-auto px-4 sm:px-6 lg:px-8","children":[["$","nav",null,{"aria-label":"面包屑","className":"text-sm text-gray-500 mb-6","children":["$","ol",null,{"className":"flex flex-wrap items-center gap-1.5","children":[["$","li",null,{"children":["$","$L8",null,{"href":"/","className":"hover:text-red-700 transition-colors","children":"首页"}]}],["$","li",null,{"aria-hidden":"true","children":"›"}],["$","li",null,{"children":["$","$L8",null,{"href":"/knowledge","className":"hover:text-red-700 transition-colors","children":"传统文化学堂"}]}],["$","li",null,{"aria-hidden":"true","children":"›"}],["$","li",null,{"children":["$","$L8",null,{"href":"/knowledge?category=meihua","className":"hover:text-red-700 transition-colors","children":"梅花易数"}]}],["$","li",null,{"aria-hidden":"true","children":"›"}],["$","li",null,{"className":"text-gray-800 font-medium truncate max-w-[200px]","children":"六十四卦速查"}]]}]}],["$","div",null,{"className":"flex gap-8","children":[["$","div",null,{"className":"flex-1 min-w-0","children":[["$","article",null,{"className":"card","children":[["$","header",null,{"className":"flex items-start gap-4 mb-6","children":[["$","span",null,{"className":"text-5xl flex-shrink-0","aria-hidden":"true","children":"☰"}],["$","div",null,{"className":"flex-1","children":[["$","h1",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 font-kai mb-3","children":"六十四卦速查"}],["$","div",null,{"className":"flex flex-wrap items-center gap-2.5","children":[["$","span",null,{"className":"px-3 py-1 rounded-full text-xs font-medium border bg-pink-50 text-pink-700 border-pink-200","children":"梅花易数"}],["$","span",null,{"className":"px-3 py-1 rounded-full text-xs font-medium border bg-blue-100 text-blue-700 border-blue-200","children":"进阶"}],["$","span",null,{"className":"text-xs text-gray-400 flex items-center gap-1","children":[["$","svg",null,{"className":"w-3.5 h-3.5","fill":"none","stroke":"currentColor","viewBox":"0 0 24 24","aria-hidden":"true","children":["$","path",null,{"strokeLinecap":"round","strokeLinejoin":"round","strokeWidth":2,"d":"M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"}]}],"预计阅读 ",15," 分钟"]}]]}],["$","p",null,{"className":"text-gray-500 mt-3 text-sm leading-relaxed","children":"六十四卦是《易经》的核心内容，由八卦两两相重而成，每卦都有独特的卦名、卦象和含义，是梅花易数断卦的基础。"}]]}]]}],["$","div",null,{"className":"mb-6 rounded-xl overflow-hidden shadow-md","children":["$","img",null,{"src":"/images/knowledge/categories/meihua.jpg","alt":"六十四卦速查","className":"w-full h-64 object-cover"}]}],["$","div",null,{"className":"flex flex-wrap gap-1.5 mb-6 pb-6 border-b border-gray-100","children":[["$","span","六十四卦",{"className":"px-2.5 py-1 bg-gray-50 text-gray-600 rounded-md text-xs border border-gray-100","children":["#","六十四卦"]}],["$","span","易经",{"className":"px-2.5 py-1 bg-gray-50 text-gray-600 rounded-md text-xs border border-gray-100","children":["#","易经"]}],"$L1a","$L1b"]}],"$L1c","$L1d"]}],"$L1e","$L1f","$L20"]}],"$L21"]}]]}]}]]
1a:["$","span","卦象",{"className":"px-2.5 py-1 bg-gray-50 text-gray-600 rounded-md text-xs border border-gray-100","children":["#","卦象"]}]
1b:["$","span","速查",{"className":"px-2.5 py-1 bg-gray-50 text-gray-600 rounded-md text-xs border border-gray-100","children":["#","速查"]}]
22:T669f,<h2 id="六十四卦概述" class="text-2xl font-bold text-gray-900 mt-8 mb-4 pb-2 border-b border-gray-100 font-kai">六十四卦概述</h2>
<p class="text-gray-700 leading-relaxed mb-3">六十四卦由八个经卦（乾兑离震巽坎艮坤）两两相重而成，上卦为外卦（天），下卦为内卦（地），每卦六爻，共三百八十四爻。六十四卦构成了《易经》的完整体系，反映了宇宙万物的发展变化规律。</p>
<h3 id="六十四卦分类速查" class="text-xl font-bold text-gray-800 mt-6 mb-3 font-kai">六十四卦分类速查</h3>
<h4 id="上经三十卦" class="text-lg font-bold text-gray-800 mt-4 mb-2">上经三十卦</h4>
<p class="font-bold text-gray-800 mt-4 mb-2">第一卦 乾为天（乾上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天行健，君子以自强不息</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：创始、刚健、成功、圆满</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二卦 坤为地（坤上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨，利牝马之贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：地势坤，君子以厚德载物</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：柔顺、包容、承载、养育</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三卦 水雷屯（坎上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨利贞，勿用有攸往</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：云雷屯，君子以经纶</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：初创艰难，需耐心经营</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四卦 山水蒙（艮上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，匪我求童蒙</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山下出泉，蒙，君子以果行育德</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：启蒙、教育、迷惑待解</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五卦 水天需（坎上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：有孚，光亨，贞吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：云上于天，需，君子以饮食宴乐</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：等待、需求、耐心</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第六卦 天水讼（乾上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：有孚窒惕，中吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天与水违行，讼，君子以作事谋始</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：争讼、纠纷、解决矛盾</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第七卦 地水师（坤上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：贞丈人吉，无咎</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：地中有水，师，君子以容民畜众</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：军队、战争、领导</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第八卦 水地比（坎上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：吉，原筮元永贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：地上有水，比，先王以建万国亲诸侯</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：亲附、合作、和谐</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第九卦 风天小畜（巽上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，密云不雨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：风行天上，小畜，君子以懿文德</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：小有积蓄、准备阶段</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十卦 天泽履（乾上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：履虎尾，不咥人，亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：上天下泽，履，君子以辨上下定民志</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：实践、履行、谨慎行事</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十一卦 地天泰（坤上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：小往大来，吉亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天地交泰，后以财成天地之道</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：通泰、和谐、顺利</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十二卦 天地否（乾上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：否之匪人，不利君子贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天地不交，否，君子以俭德辟难</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：闭塞、不通、困难</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十三卦 天火同人（乾上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：同人于野，亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天与火，同人，君子以类族辨物</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：团结、合作、志同道合</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十四卦 火天大有（离上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：火在天上，大有，君子以遏恶扬善</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：大有收获、丰盛富裕</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十五卦 地山谦（坤上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，君子有终</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：地中有山，谦，君子以裒多益寡</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：谦虚、退让、美德</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十六卦 雷地豫（震上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利建侯行师</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷出地奋，豫，先王以作乐崇德</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：愉悦、安逸、准备</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十七卦 泽雷随（兑上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨利贞，无咎</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽中有雷，随，君子以向晦入宴息</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：随从、跟随、顺应</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十八卦 山风蛊（艮上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨，利涉大川</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山下有风，蛊，君子以振民育德</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：整治、革新、除弊</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第十九卦 地泽临（坤上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽上有地，临，君子以教思无穷</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：临近、监督、管理</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十卦 风地观（巽上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：盥而不荐，有孚颙若</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：风行地上，观，先王以省方观民设教</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：观察、观望、审时度势</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十一卦 火雷噬嗑（离上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，利用狱</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷电噬嗑，先王以明罚敕法</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：咬合、审判、排除障碍</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十二卦 山火贲（艮上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，小利有攸往</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山下有火，贲，君子以明庶政</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：装饰、文饰、美化</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十三卦 山地剥（艮上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：不利有攸往</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山附于地，剥，上以厚下安宅</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：剥落、衰退、去旧</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十四卦 地雷复（坤上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，出入无疾</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷在地中，复，先王以至日闭关</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：恢复、回归、新生</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十五卦 天雷无妄（乾上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天下雷行，物与无妄，先王以茂对时育万物</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：真诚、无妄、顺其自然</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十六卦 山天大畜（艮上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利贞，不家食吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天在山中，大畜，君子以多识前言往行</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：积蓄、储备、厚积薄发</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十七卦 山雷颐（艮上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：贞吉，观颐自求口实</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山下有雷，颐，君子以慎言语节饮食</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：颐养、保养、自食其力</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十八卦 泽风大过（兑上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：栋桡，利有攸往，亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽灭木，大过，君子以独立不惧</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：过度、非常、力挽狂澜</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第二十九卦 坎为水（坎上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：习坎，有孚维心亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：水洊至，习坎，君子以常德行习教事</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：险陷、困难、积累</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十卦 离为火（离上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利贞，亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：明两作，离，大人以继明照于四方</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：光明、依附、文明</p>
<h4 id="下经三十四卦" class="text-lg font-bold text-gray-800 mt-4 mb-2">下经三十四卦</h4>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十一卦 泽山咸（兑上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，利贞，取女吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山上有泽，咸，君子以虚受人</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：感应、交流、爱情</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十二卦 雷风恒（震上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，无咎，利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷风，恒，君子以立不易方</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：恒久、坚持、稳定</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十三卦 天山遁（乾上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，小利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天下有山，遁，君子以远小人</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：退隐、躲避、退守</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十四卦 雷天大壮（震上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷在天上，大壮，君子以非礼弗履</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：强壮、盛大、慎用力量</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十五卦 火地晋（离上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：康侯用锡马蕃庶</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：明出地上，晋，君子以自昭明德</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：进升、前进、光明</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十六卦 地火明夷（坤上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利艰贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：明入地中，明夷，君子以莅众用晦而明</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：受伤、隐藏、韬光养晦</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十七卦 风火家人（巽上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利女贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：风自火出，家人，君子以言有物而行有恒</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：家庭、家人、和谐</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十八卦 火泽睽（离上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：小事吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：上火下泽，睽，君子以同而异</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：乖离、分歧、求同存异</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第三十九卦 水山蹇（坎上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利西南，不利东北</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山上有水，蹇，君子以反身修德</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：艰难、险阻、反省</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十卦 雷水解（震上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利西南，无所往</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷雨作，解，君子以赦过宥罪</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：解除、解脱、缓解</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十一卦 山泽损（艮上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：有孚，元吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山下有泽，损，君子以惩忿窒欲</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：减损、损失、牺牲</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十二卦 风雷益（巽上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：利有攸往，利涉大川</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：风雷，益，君子以见善则迁有过则改</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：增益、利益、进步</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十三卦 泽天夬（兑上乾下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：扬于王庭，孚号有厉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽上于天，夬，君子以施禄及下</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：决断、果决、清除</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十四卦 天风姤（乾上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：女壮，勿用取女</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：天下有风，姤，后以施命诰四方</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：相遇、邂逅、不期而遇</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十五卦 泽地萃（兑上坤下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，王假有庙</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽上于地，萃，君子以除戎器戒不虞</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：聚集、精华、汇聚</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十六卦 地风升（坤上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元亨，用见大人</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：地中生木，升，君子以顺德积小以高大</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：上升、晋升、发展</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十七卦 泽水困（兑上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，贞大人吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽无水，困，君子以致命遂志</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：困境、困顿、坚守</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十八卦 水风井（坎上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：改邑不改井，无丧无得</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：木上有水，井，君子以劳民劝相</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：源泉、滋养、利用</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第四十九卦 泽火革（兑上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：巳日乃孚，元亨利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽中有火，革，君子以治历明时</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：变革、革新、革命</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十卦 火风鼎（离上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：元吉，亨</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：木上有火，鼎，君子以正位凝命</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：鼎立、更新、烹饪</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十一卦 震为雷（震上震下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，震来虩虩</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：洊雷，震，君子以恐惧修省</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：震动、惊醒、戒惧</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十二卦 艮为山（艮上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：艮其背，不获其身</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：兼山，艮，君子以思不出其位</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：停止、静止、安守本分</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十三卦 风山渐（巽上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：女归吉，利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山上有木，渐，君子以居贤德善俗</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：渐进、循序渐进、稳步</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十四卦 雷泽归妹（震上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：征凶，无攸利</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽上有雷，归妹，君子以永终知敝</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：婚嫁、结合、不当</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十五卦 雷火丰（震上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，王假之</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：雷电皆至，丰，君子以折狱致刑</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：丰盛、丰收、盛大</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十六卦 火山旅（离上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：小亨，旅贞吉</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山上有火，旅，君子以明慎用刑而不留狱</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：旅行、漂泊、变动</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十七卦 巽为风（巽上巽下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：小亨，利有攸往</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：随风，巽，君子以申命行事</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：顺入、谦逊、渗透</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十八卦 兑为泽（兑上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：丽泽，兑，君子以朋友讲习</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：喜悦、交流、言谈</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第五十九卦 风水涣（巽上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，王假有庙</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：风行水上，涣，先王以享于帝立庙</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：涣散、离散、分散</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第六十卦 水泽节（坎上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，苦节不可贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽上有水，节，君子以制数度议德行</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：节制、调节、适度</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第六十一卦 风泽中孚（巽上兑下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：豚鱼吉，利涉大川</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：泽上有风，中孚，君子以议狱缓死</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：诚信、真诚、信任</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第六十二卦 雷山小过（震上艮下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：山上有雷，小过，君子以行过乎恭</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：小有过失、谨慎</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第六十三卦 水火既济（坎上离下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨小，利贞</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：水在火上，既济，君子以思患而预防之</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：成功、完成、圆满</p>
<p class="font-bold text-gray-800 mt-4 mb-2">第六十四卦 火水未济（离上坎下）</p>
<p class="text-gray-700 leading-relaxed mb-3">卦辞：亨，小狐汔济</p>
<p class="text-gray-700 leading-relaxed mb-3">象曰：火在水上，未济，君子以慎辨物居方</p>
<p class="text-gray-700 leading-relaxed mb-3">含义：未完成、继续努力、新的开始</p>
<h3 id="六十四卦的记忆方法" class="text-xl font-bold text-gray-800 mt-6 mb-3 font-kai">六十四卦的记忆方法</h3>
<ol class="list-disc pl-6 space-y-1.5 mb-4"><li class="text-gray-700 leading-relaxed"><strong>按卦序记忆</strong>：按照《序卦传》的排列顺序，理解前后卦之间的逻辑关系</li><li class="text-gray-700 leading-relaxed"><strong>按上经下经分组</strong>：上经三十卦讲天地自然之道，下经三十四卦讲人伦社会之理</li><li class="text-gray-700 leading-relaxed"><strong>按八宫分组</strong>：以八纯卦为首，每宫七卦（京房八宫卦法）</li><li class="text-gray-700 leading-relaxed"><strong>按卦象对比</strong>：如泰卦与否卦、既济与未济等成对卦象</li></ol>
<h3 id="卦象在占卜中的应用" class="text-xl font-bold text-gray-800 mt-6 mb-3 font-kai">卦象在占卜中的应用</h3>
<p class="text-gray-700 leading-relaxed mb-3">梅花易数起卦后，需要结合卦名、卦辞、爻辞以及体用生克来综合判断：</p>
<ol class="list-disc pl-6 space-y-1.5 mb-4"><li class="text-gray-700 leading-relaxed"><strong>看卦名</strong>：卦名本身就包含了吉凶信息</li><li class="text-gray-700 leading-relaxed"><strong>看卦辞</strong>：卦辞是整卦的总结性判断</li><li class="text-gray-700 leading-relaxed"><strong>看爻辞</strong>：动爻的爻辞提供具体建议</li><li class="text-gray-700 leading-relaxed"><strong>看体用生克</strong>：体卦与用卦的五行关系</li><li class="text-gray-700 leading-relaxed"><strong>看互卦变卦</strong>：互卦反映过程，变卦反映结果</li></ol>
<h3 id="学习要点" class="text-xl font-bold text-gray-800 mt-6 mb-3 font-kai">学习要点</h3>
<ol class="list-disc pl-6 space-y-1.5 mb-4"><li class="text-gray-700 leading-relaxed">六十四卦不必死记硬背，先掌握八卦的基本属性</li><li class="text-gray-700 leading-relaxed">理解卦序的逻辑有助于记忆</li><li class="text-gray-700 leading-relaxed">每卦的卦辞是最精炼的核心含义</li><li class="text-gray-700 leading-relaxed">同类卦象对比学习效果更好（如泰与否、损与益）</li><li class="text-gray-700 leading-relaxed">实际操作中不断翻查卦书，久而久之自然熟记</li><li class="text-gray-700 leading-relaxed">卦象解读需要结合具体问题，不可生搬硬套</li></ol>1c:["$","div",null,{"className":"prose max-w-none","id":"article-content","dangerouslySetInnerHTML":{"__html":"$22"}}]
1d:["$","div",null,{"className":"flex flex-wrap gap-2 mt-8 pt-6 border-t border-gray-100","children":[["$","span","六十四卦",{"className":"px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs","children":["#","六十四卦"]}],["$","span","易经",{"className":"px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs","children":["#","易经"]}],["$","span","卦象",{"className":"px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs","children":["#","卦象"]}],["$","span","速查",{"className":"px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs","children":["#","速查"]}]]}]
1e:["$","nav",null,{"aria-label":"文章导航","className":"flex justify-between gap-4 mt-6","children":[["$","$L8",null,{"href":"/knowledge/bazi-shishen","className":"flex-1 card text-left hover:shadow-md transition-all group","children":[["$","div",null,{"className":"text-xs text-gray-400 mb-1 flex items-center gap-1","children":[["$","svg",null,{"className":"w-3 h-3","fill":"none","stroke":"currentColor","viewBox":"0 0 24 24","aria-hidden":"true","children":["$","path",null,{"strokeLinecap":"round","strokeLinejoin":"round","strokeWidth":2,"d":"M15 19l-7-7 7-7"}]}],"上一篇"]}],["$","div",null,{"className":"font-medium text-gray-800 group-hover:text-red-700 transition-colors truncate","children":"十神详解与含义"}]]}],["$","$L8",null,{"href":"/knowledge/meihua-number","className":"flex-1 card text-right hover:shadow-md transition-all group","children":[["$","div",null,{"className":"text-xs text-gray-400 mb-1 flex items-center gap-1 justify-end","children":["下一篇",["$","svg",null,{"className":"w-3 h-3","fill":"none","stroke":"currentColor","viewBox":"0 0 24 24","aria-hidden":"true","children":["$","path",null,{"strokeLinecap":"round","strokeLinejoin":"round","strokeWidth":2,"d":"M9 5l7 7-7 7"}]}]]}],["$","div",null,{"className":"font-medium text-gray-800 group-hover:text-red-700 transition-colors truncate","children":"数字起卦法"}]]}]]}]
1f:["$","section",null,{"className":"mt-8","aria-label":"相关文章","children":[["$","h2",null,{"className":"text-lg font-bold text-gray-900 mb-4 font-kai","children":"相关文章"}],["$","div",null,{"className":"grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4","children":[["$","$L8","meihua-intro",{"href":"/knowledge/meihua-intro","className":"card text-left hover:shadow-md transition-all group","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","span",null,{"className":"text-2xl","aria-hidden":"true","children":"🌸"}],["$","div",null,{"className":"min-w-0","children":[["$","div",null,{"className":"font-medium text-sm text-gray-800 group-hover:text-red-700 transition-colors truncate","children":"梅花易数入门"}],["$","div",null,{"className":"text-xs text-gray-400 mt-0.5","children":["梅花易数"," · ","进阶"]}]]}]]}]}],["$","$L8","meihua-number",{"href":"/knowledge/meihua-number","className":"card text-left hover:shadow-md transition-all group","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","span",null,{"className":"text-2xl","aria-hidden":"true","children":"🔢"}],["$","div",null,{"className":"min-w-0","children":[["$","div",null,{"className":"font-medium text-sm text-gray-800 group-hover:text-red-700 transition-colors truncate","children":"数字起卦法"}],["$","div",null,{"className":"text-xs text-gray-400 mt-0.5","children":["梅花易数"," · ","入门"]}]]}]]}]}],["$","$L8","meihua-coin",{"href":"/knowledge/meihua-coin","className":"card text-left hover:shadow-md transition-all group","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","span",null,{"className":"text-2xl","aria-hidden":"true","children":"🪙"}],["$","div",null,{"className":"min-w-0","children":[["$","div",null,{"className":"font-medium text-sm text-gray-800 group-hover:text-red-700 transition-colors truncate","children":"硬币起卦法"}],["$","div",null,{"className":"text-xs text-gray-400 mt-0.5","children":["梅花易数"," · ","入门"]}]]}]]}]}]]}]]}]
20:["$","section",null,{"className":"mt-8","aria-label":"相关工具","children":[["$","h2",null,{"className":"text-lg font-bold text-gray-900 mb-4 font-kai","children":"在线工具"}],["$","$L8",null,{"href":"/meihua","className":"card flex items-center gap-4 p-4 hover:shadow-md transition-all group","children":[["$","span",null,{"className":"text-3xl","aria-hidden":"true","children":"✿"}],["$","div",null,{"className":"flex-1","children":[["$","div",null,{"className":"font-medium text-gray-800 group-hover:text-red-700 transition-colors","children":"梅花易数起卦"}],["$","div",null,{"className":"text-xs text-gray-400 mt-0.5","children":"时间或数字起卦，体用生克断吉凶"}]]}],["$","svg",null,{"className":"w-5 h-5 text-gray-300 group-hover:text-red-600 transition-colors","fill":"none","stroke":"currentColor","viewBox":"0 0 24 24","aria-hidden":"true","children":["$","path",null,{"strokeLinecap":"round","strokeLinejoin":"round","strokeWidth":2,"d":"M9 5l7 7-7 7"}]}]]}]]}]
21:["$","aside",null,{"className":"hidden lg:block w-56 flex-shrink-0","aria-label":"目录","children":["$","div",null,{"className":"sticky top-24","children":["$","div",null,{"className":"card !p-4","children":[["$","h2",null,{"className":"text-sm font-bold text-gray-700 mb-3 flex items-center gap-1.5","children":[["$","svg",null,{"className":"w-4 h-4","fill":"none","stroke":"currentColor","viewBox":"0 0 24 24","aria-hidden":"true","children":["$","path",null,{"strokeLinecap":"round","strokeLinejoin":"round","strokeWidth":2,"d":"M4 6h16M4 12h16M4 18h7"}]}],"目录"]}],["$","nav",null,{"className":"space-y-1","children":[["$","a","0",{"href":"#六十四卦概述","className":"block text-sm text-gray-500 hover:text-red-700 transition-colors ","children":"六十四卦概述"}],["$","a","1",{"href":"#六十四卦分类速查","className":"block text-sm text-gray-500 hover:text-red-700 transition-colors pl-4 text-xs","children":"六十四卦分类速查"}],["$","a","2",{"href":"#六十四卦的记忆方法","className":"block text-sm text-gray-500 hover:text-red-700 transition-colors pl-4 text-xs","children":"六十四卦的记忆方法"}],["$","a","3",{"href":"#卦象在占卜中的应用","className":"block text-sm text-gray-500 hover:text-red-700 transition-colors pl-4 text-xs","children":"卦象在占卜中的应用"}],["$","a","4",{"href":"#学习要点","className":"block text-sm text-gray-500 hover:text-red-700 transition-colors pl-4 text-xs","children":"学习要点"}]]}]]}]}]}]
16:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
c:null
e:{"metadata":[["$","title","0",{"children":"六十四卦速查 - 传统文化知识"}],["$","meta","1",{"name":"description","content":"六十四卦是《易经》的核心内容，由八卦两两相重而成，每卦都有独特的卦名、卦象和含义，是梅花易数断卦的基础。"}],["$","meta","2",{"name":"keywords","content":"六十四卦,易经,卦象,速查"}],["$","link","3",{"rel":"canonical","href":"https://ming8.online/knowledge/meihua-liushisi"}],["$","meta","4",{"name":"baidu-site-verification","content":"codeva-hyw462vt6N"}],["$","meta","5",{"property":"og:title","content":"六十四卦速查 - 知微阁"}],["$","meta","6",{"property":"og:description","content":"六十四卦是《易经》的核心内容，由八卦两两相重而成，每卦都有独特的卦名、卦象和含义，是梅花易数断卦的基础。"}],["$","meta","7",{"property":"og:url","content":"https://ming8.online/knowledge/meihua-liushisi"}],["$","meta","8",{"property":"og:site_name","content":"知微阁"}],["$","meta","9",{"property":"og:locale","content":"zh_CN"}],["$","meta","10",{"property":"og:image","content":"https://ming8.online/images/knowledge/categories/meihua.jpg"}],["$","meta","11",{"property":"og:type","content":"article"}],["$","meta","12",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","13",{"name":"twitter:title","content":"六十四卦速查 - 知微阁"}],["$","meta","14",{"name":"twitter:description","content":"六十四卦是《易经》的核心内容，由八卦两两相重而成，每卦都有独特的卦名、卦象和含义，是梅花易数断卦的基础。"}],["$","meta","15",{"name":"twitter:image","content":"https://ming8.online/images/knowledge/categories/meihua.jpg"}]],"error":null,"digest":"$undefined"}
19:"$e:metadata"
